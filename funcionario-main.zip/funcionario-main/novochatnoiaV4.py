#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import subprocess
import sys
import time
import re
from datetime import datetime
from pathlib import Path

import pandas as pd


def extrair_id_video(url):
    """Extrai o ID do vídeo da URL do YouTube."""
    padroes = [
        r'(?:v=|\/)([0-9A-Za-z_-]{11})(?:[?&]|$)',
        r'(?:youtu\.be\/)([0-9A-Za-z_-]{11})',
        r'(?:embed\/)([0-9A-Za-z_-]{11})'
    ]
    
    for padrao in padroes:
        match = re.search(padrao, url)
        if match:
            return match.group(1)
    
    raise ValueError(f"Não foi possível extrair o ID do vídeo de: {url}")


def obter_titulo_video(video_id):
    """Tenta obter o título do vídeo usando yt-dlp."""
    try:
        url = f"https://www.youtube.com/watch?v={video_id}"
        resultado = subprocess.run(
            ["yt-dlp", "--get-title", url],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if resultado.returncode == 0 and resultado.stdout.strip():
            return resultado.stdout.strip()
        else:
            return None
    except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
        return None


def esperar_arquivo_estavel(path, timeout=10):
    """Espera o arquivo terminar de ser escrito."""
    last_size = -1

    for _ in range(timeout * 2):
        if not path.exists():
            time.sleep(0.5)
            continue

        size = path.stat().st_size

        if size == last_size:
            return True

        last_size = size
        time.sleep(0.5)

    return True


def converter(json_file, pasta_destino, video_id):
    """Converte o JSON para CSV e XLSX na pasta de destino."""
    print(f"\nConvertendo {json_file.name}...")

    esperar_arquivo_estavel(json_file)

    with open(json_file, "r", encoding="utf-8") as f:
        chat = json.load(f)

    df = pd.DataFrame(chat)

    df = df.rename(columns={
        "user_display_name": "Nome",
        "comment": "Mensagem",
        "timestamp": "Tempo"
    })

    df = df[["Nome", "Mensagem", "Tempo"]]

    df["Mensagem"] = (
        df["Mensagem"]
        .fillna("")
        .str.replace(r"[\r\n\t]+", " ", regex=True)
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )

    df = df.drop_duplicates()

    # Salva na pasta de destino com o novo nome
    base_nome = f"{video_id}_chat"
    csv = pasta_destino / f"{base_nome}.csv"
    xlsx = pasta_destino / f"{base_nome}.xlsx"

    df.to_csv(csv, sep=";", index=False, encoding="utf-8-sig")
    df.to_excel(xlsx, index=False)

    print(f"  ✓ {csv.name}")
    print(f"  ✓ {xlsx.name}")

    return csv, xlsx


def criar_arquivos_info(video_id, url, titulo, pasta_destino):
    """Cria os arquivos de informação na pasta de destino."""
    
    # Arquivo de título
    titulo_path = pasta_destino / f"{video_id}_titulo.txt"
    with open(titulo_path, "w", encoding="utf-8") as f:
        if titulo:
            f.write(titulo)
        else:
            f.write("Título não disponível.")
    print(f"  ✓ {titulo_path.name}")
    
    # Arquivo info.json
    info_path = pasta_destino / f"{video_id}_info.json"
    info_data = {
        "id": video_id,
        "url": url,
        "titulo": titulo,
        "data_download": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    with open(info_path, "w", encoding="utf-8") as f:
        json.dump(info_data, f, indent=2, ensure_ascii=False)
    print(f"  ✓ {info_path.name}")


def baixar_para_pasta(video_id, url):
    """Baixa o chat e coloca os arquivos na pasta apropriada."""
    
    # Cria a pasta de destino
    pasta_destino = Path(video_id)
    pasta_destino.mkdir(exist_ok=True)
    
    # Obtém o título do vídeo
    print(f"\nObtendo título do vídeo {video_id}...")
    titulo = obter_titulo_video(video_id)
    if titulo:
        print(f"  ✓ Título: {titulo}")
    else:
        print(f"  ⚠ Título não disponível")
    
    # Salva os arquivos info antes de baixar
    criar_arquivos_info(video_id, url, titulo, pasta_destino)
    
    # Muda para a pasta de destino para baixar diretamente lá
    cwd_original = Path.cwd()
    
    try:
        # Baixa o chat na pasta de destino
        print(f"\nBaixando: {url}")
        
        # Executa o yt-chat-downloader na pasta de destino
        subprocess.run(
            ["yt-chat-downloader", url],
            cwd=pasta_destino,
            check=True
        )
        
        # Procura o arquivo JSON baixado na pasta de destino
        json_files = list(pasta_destino.glob("youtube_chat_*.json"))
        
        if not json_files:
            raise RuntimeError("Nenhum JSON foi criado.")
        
        # Pega o arquivo mais recente
        json_file = sorted(json_files, key=lambda p: p.stat().st_mtime)[-1]
        
        # Converte o JSON na pasta de destino
        converter(json_file, pasta_destino, video_id)
        
        # Renomeia o arquivo JSON original
        novo_nome_json = pasta_destino / f"{video_id}_chat.json"
        json_file.rename(novo_nome_json)
        print(f"  ✓ {novo_nome_json.name}")
        
    except subprocess.CalledProcessError as e:
        print(f"Erro ao baixar: {e}")
        # Volta para o diretório original em caso de erro
        raise
    finally:
        # Volta para o diretório original
        if cwd_original != Path.cwd():
            import os
            os.chdir(cwd_original)


def limpar_nomes_lixo():
    """Corrige arquivos quebrados tipo '.json .csv'."""
    for f in Path(".").iterdir():
        if " " in f.suffix:
            novo = Path(str(f).replace(" ", ""))
            f.rename(novo)


def main():
    if len(sys.argv) < 2:
        print("Uso:")
        print("python3 script.py URL1 [URL2 ...]")
        return

    for url in sys.argv[1:]:
        try:
            # Extrai o ID do vídeo
            video_id = extrair_id_video(url)
            print(f"\n=== Processando vídeo: {video_id} ===")
            
            # Baixa e organiza tudo na pasta
            baixar_para_pasta(video_id, url)
            
            print(f"\n=== Processamento concluído: {video_id} ===")
            print(f"Todos os arquivos estão em: {video_id}/")

        except Exception as e:
            print(f"Erro ao processar {url}: {e}")
            continue


if __name__ == "__main__":
    main()